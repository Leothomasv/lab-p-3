
#include "Priest.h"

Priest::Priest() {

}