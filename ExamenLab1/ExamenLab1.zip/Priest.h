#pragma once
#include "Character.h"

#ifndef PRIEST_H
#define PRIEST_H

class Priest {
public:
	Priest();
	void Special();

};

#endif 

