#pragma once
#include "Character.h"

#ifndef SORCERESS_H
#define SORCERESS_H

class Soreceress {
public:
	Soreceress();


};

#endif SORCERESS_H