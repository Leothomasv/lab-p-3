
#include "Berserk.h"

Berserk::Berserk() {

}