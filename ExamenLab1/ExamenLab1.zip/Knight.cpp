
#include "Knight.h"

Knight::Knight () {

}
