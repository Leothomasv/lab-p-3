
#include "Sorceress.h"

Soreceress::Soreceress() {

}