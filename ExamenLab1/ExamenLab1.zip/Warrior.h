#pragma once
#include "Character.h" 

#ifndef WARRIOR_H
#define WARRIOR_H

class Warrior{
public:
	Warrior();
	void Special();
};

#endif 