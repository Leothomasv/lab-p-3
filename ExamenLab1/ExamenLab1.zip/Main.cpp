
#include <iostream>
#include "Berserk.h"
#include "Character.h"
#include "Knight.h"
#include "Priest.h"
#include "Sorceress.h"
#include "Warrior.h"

#include "CharacterTest.h"
#include "SorterTest.h"

#include <conio.h>
int main{

}