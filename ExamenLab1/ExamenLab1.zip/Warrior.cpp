
#include "Warrior.h"

Warrior::Warrior() {

}