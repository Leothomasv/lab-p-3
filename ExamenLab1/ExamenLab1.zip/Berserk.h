#pragma once
#include "Character.h" 


#ifndef BERSERK_H
#define BERSERK_H

class Berserk {
public:
	this->attack = 80;
	this->magic = 40;
	this->def = 45;
	this->

	Berserk();
	void Special();
};

#endif 
