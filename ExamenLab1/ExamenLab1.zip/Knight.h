#pragma once
#include "Character.h"

#ifndef KNIGHT_H
#define KNIGHT_H

class Knight {
public:
	Knight();
	void Special();
};

#endif
